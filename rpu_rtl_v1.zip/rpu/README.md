# RPU — Relentless Processing Unit
## Rajput Tech (RT Ecosystem)

> "B200 की performance, B200 की 1/8th cost पर"

---

## File Structure

```
rpu/
├── README.md                    ← यह file
├── rpu_top.v                    ← Top-level chip integration
│
├── matrix_engine/
│   ├── pe_cell.v                ← Processing Element (systolic cell)
│   ├── systolic_array.v         ← 512×512 Matrix Engine
│   └── sparse_engine.v         ← Sparse Skipping Engine (main innovation)
│
├── memory/
│   └── memory_controller.v     ← L3 SRAM + HBM3 controller
│
└── testbench/
    └── rpu_tb.v                ← Complete testbench (1 लाख+ tests)
```

---

## Simulate करने का तरीका (Free Tools)

### Option 1: Verilator (Linux/Mac)
```bash
# Install
sudo apt install verilator

# Compile
verilator --cc rpu_tb.v pe_cell.v systolic_array.v sparse_engine.v --exe --build

# Run
./obj_dir/Vrpu_tb
```

### Option 2: EDA Playground (Browser — phone पर भी)
1. जाएं: https://edaplayground.com
2. Files paste करें
3. "Run" दबाएं
4. Free है, account बनाना होगा

### Option 3: iverilog (सबसे आसान)
```bash
sudo apt install iverilog
iverilog -o rpu_sim rpu_tb.v pe_cell.v systolic_array.v sparse_engine.v
vvp rpu_sim
```

---

## Patent-Worthy Innovations

1. **Sparse Skipping Engine (SSE)** — Hardware-level zero detection
2. **Unified Training-Inference Dataflow** — Dual-mode architecture
3. **RPU-Link Interconnect** — 900 GB/s chip-to-chip
4. **Adaptive Precision Engine** — Auto BF16/INT8/INT4 selection

---

## Performance Targets

| Metric | RPU v1 | B200 |
|---|---|---|
| Single chip (BF16) | 2.5 PFLOPS | 20 PFLOPS |
| Price | $3,000-5,000 | $35,000 |
| Performance/Dollar | 700 GFLOPS/$ | 571 GFLOPS/$ |
| 8-chip cluster | ~20 PFLOPS | — |

---

*Rajput Tech (RT Ecosystem) — Confidential IP*
