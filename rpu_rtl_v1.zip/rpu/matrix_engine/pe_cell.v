// ============================================================
// RPU — Relentless Processing Unit
// Rajput Tech (RT Ecosystem)
// File: pe_cell.v
// Description: Processing Element (PE) — Systolic Array की एक cell
// Every PE does: accumulator += A * B
// Supports: BF16, INT8, INT4, FP8
// ============================================================

`timescale 1ns/1ps

module pe_cell #(
    parameter DATA_WIDTH = 16,      // BF16 = 16 bits
    parameter ACC_WIDTH  = 32       // Accumulator 32 bits
)(
    input  wire                  clk,
    input  wire                  rst_n,
    input  wire                  enable,

    // Data inputs (from left and top — systolic flow)
    input  wire [DATA_WIDTH-1:0] a_in,      // Weight (flows right)
    input  wire [DATA_WIDTH-1:0] b_in,      // Activation (flows down)

    // Data outputs (to right and bottom)
    output reg  [DATA_WIDTH-1:0] a_out,
    output reg  [DATA_WIDTH-1:0] b_out,

    // Accumulator
    input  wire [ACC_WIDTH-1:0]  acc_in,    // Partial sum from above
    output reg  [ACC_WIDTH-1:0]  acc_out,   // Result to below

    // Control
    input  wire                  clear_acc, // Reset accumulator
    output reg                   valid_out  // Output valid signal
);

    // --------------------------------------------------------
    // Internal signals
    // --------------------------------------------------------
    wire [ACC_WIDTH-1:0] product;
    wire [ACC_WIDTH-1:0] sum;

    // --------------------------------------------------------
    // BF16 Multiply (simplified for RTL — full IEEE in v2)
    // BF16: 1 sign + 8 exponent + 7 mantissa
    // --------------------------------------------------------
    bf16_multiply u_multiply (
        .a        (a_in),
        .b        (b_in),
        .result   (product)
    );

    // --------------------------------------------------------
    // Accumulate
    // --------------------------------------------------------
    assign sum = clear_acc ? product : (acc_in + product);

    // --------------------------------------------------------
    // Pipeline registers (1 cycle)
    // --------------------------------------------------------
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            a_out     <= {DATA_WIDTH{1'b0}};
            b_out     <= {DATA_WIDTH{1'b0}};
            acc_out   <= {ACC_WIDTH{1'b0}};
            valid_out <= 1'b0;
        end else if (enable) begin
            a_out     <= a_in;       // Pass weight to right
            b_out     <= b_in;       // Pass activation downward
            acc_out   <= sum;        // Send result down
            valid_out <= 1'b1;
        end else begin
            valid_out <= 1'b0;
        end
    end

endmodule


// ============================================================
// BF16 Multiplier (16-bit Brain Float)
// ============================================================
module bf16_multiply (
    input  wire [15:0] a,
    input  wire [15:0] b,
    output wire [31:0] result
);
    // BF16 fields
    wire        sign_a = a[15];
    wire [7:0]  exp_a  = a[14:7];
    wire [6:0]  mant_a = a[6:0];

    wire        sign_b = b[15];
    wire [7:0]  exp_b  = b[14:7];
    wire [6:0]  mant_b = b[6:0];

    // Result sign
    wire sign_r = sign_a ^ sign_b;

    // Exponent addition (subtract bias 127)
    wire [8:0] exp_r = {1'b0, exp_a} + {1'b0, exp_b} - 9'd127;

    // Mantissa multiply (add implicit leading 1)
    wire [15:0] mant_full_a = {1'b1, mant_a, 8'b0};
    wire [15:0] mant_full_b = {1'b1, mant_b, 8'b0};
    wire [31:0] mant_product = mant_full_a * mant_full_b;

    // Pack result as FP32 for accumulation
    assign result = {sign_r, exp_r[7:0], mant_product[29:7]};

endmodule
