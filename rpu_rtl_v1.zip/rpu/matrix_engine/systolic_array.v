// ============================================================
// RPU — Relentless Processing Unit
// Rajput Tech (RT Ecosystem)
// File: systolic_array.v
// Description: 512×512 Systolic Array — RPU का दिल
//
// यह chip का सबसे important हिस्सा है।
// हर clock cycle में 512×512 = 262,144 multiply-accumulate
// operations होती हैं।
//
// Peak Performance (BF16 @ 2GHz):
//   = 512 × 512 × 2 ops × 2GHz
//   = 1,048,576 × 2,000,000,000
//   = ~1 PFLOPS per array
//   4 arrays × 1 PFLOPS = ~4 PFLOPS (with overhead ~2.5 PFLOPS)
// ============================================================

`timescale 1ns/1ps

module systolic_array #(
    parameter ARRAY_SIZE  = 512,     // 512×512
    parameter DATA_WIDTH  = 16,      // BF16
    parameter ACC_WIDTH   = 32       // FP32 accumulator
)(
    input  wire                              clk,
    input  wire                              rst_n,
    input  wire                              enable,

    // Weight matrix input (left edge — ARRAY_SIZE rows)
    input  wire [DATA_WIDTH*ARRAY_SIZE-1:0]  weight_in,
    input  wire                              weight_valid,

    // Activation input (top edge — ARRAY_SIZE cols)
    input  wire [DATA_WIDTH*ARRAY_SIZE-1:0]  act_in,
    input  wire                              act_valid,

    // Output (bottom edge — result matrix row)
    output wire [ACC_WIDTH*ARRAY_SIZE-1:0]   result_out,
    output wire                              result_valid,

    // Control
    input  wire                              clear_acc,
    input  wire                              start,
    output wire                              done
);

    // --------------------------------------------------------
    // Internal wire arrays for systolic connections
    // a_wire[row][col] — weight flowing right
    // b_wire[row][col] — activation flowing down
    // acc_wire[row][col] — accumulator flowing down
    // --------------------------------------------------------

    wire [DATA_WIDTH-1:0] a_wire [0:ARRAY_SIZE][0:ARRAY_SIZE-1];
    wire [DATA_WIDTH-1:0] b_wire [0:ARRAY_SIZE-1][0:ARRAY_SIZE];
    wire [ACC_WIDTH-1:0]  acc_wire [0:ARRAY_SIZE][0:ARRAY_SIZE-1];
    wire                  valid_wire [0:ARRAY_SIZE][0:ARRAY_SIZE-1];

    // --------------------------------------------------------
    // Connect input edges
    // --------------------------------------------------------
    genvar i;
    generate
        for (i = 0; i < ARRAY_SIZE; i = i + 1) begin : input_connect
            // Weight feeds from left (column 0)
            assign a_wire[0][i] = weight_valid ?
                weight_in[DATA_WIDTH*(i+1)-1 : DATA_WIDTH*i] :
                {DATA_WIDTH{1'b0}};

            // Activation feeds from top (row 0)
            assign b_wire[i][0] = act_valid ?
                act_in[DATA_WIDTH*(i+1)-1 : DATA_WIDTH*i] :
                {DATA_WIDTH{1'b0}};

            // Accumulator starts at 0 from top
            assign acc_wire[0][i] = {ACC_WIDTH{1'b0}};
        end
    endgenerate

    // --------------------------------------------------------
    // Generate 512×512 PE array
    // --------------------------------------------------------
    genvar row, col;
    generate
        for (row = 0; row < ARRAY_SIZE; row = row + 1) begin : pe_row
            for (col = 0; col < ARRAY_SIZE; col = col + 1) begin : pe_col

                pe_cell #(
                    .DATA_WIDTH (DATA_WIDTH),
                    .ACC_WIDTH  (ACC_WIDTH)
                ) u_pe (
                    .clk       (clk),
                    .rst_n     (rst_n),
                    .enable    (enable),

                    // Systolic connections
                    .a_in      (a_wire[row][col]),
                    .b_in      (b_wire[row][col]),
                    .a_out     (a_wire[row][col+1]),    // Pass right
                    .b_out     (b_wire[row+1][col]),    // Pass down

                    // Accumulator chain (top to bottom)
                    .acc_in    (acc_wire[row][col]),
                    .acc_out   (acc_wire[row+1][col]),

                    .clear_acc (clear_acc),
                    .valid_out (valid_wire[row+1][col])
                );
            end
        end
    endgenerate

    // --------------------------------------------------------
    // Output — bottom edge results
    // --------------------------------------------------------
    genvar k;
    generate
        for (k = 0; k < ARRAY_SIZE; k = k + 1) begin : output_connect
            assign result_out[ACC_WIDTH*(k+1)-1 : ACC_WIDTH*k] =
                acc_wire[ARRAY_SIZE][k];
        end
    endgenerate

    // --------------------------------------------------------
    // Done signal — after ARRAY_SIZE cycles from start
    // --------------------------------------------------------
    reg [$clog2(ARRAY_SIZE+1)-1:0] cycle_count;
    reg                             done_reg;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            cycle_count <= 0;
            done_reg    <= 1'b0;
        end else if (start) begin
            cycle_count <= 0;
            done_reg    <= 1'b0;
        end else if (enable && cycle_count < ARRAY_SIZE) begin
            cycle_count <= cycle_count + 1;
            if (cycle_count == ARRAY_SIZE - 1)
                done_reg <= 1'b1;
        end else begin
            done_reg <= 1'b0;
        end
    end

    assign done         = done_reg;
    assign result_valid = valid_wire[ARRAY_SIZE][0];

endmodule
