// ============================================================
// RPU — Relentless Processing Unit
// Rajput Tech (RT Ecosystem)
// File: memory_controller.v
// Description: Memory Subsystem Controller
//
// Memory Hierarchy:
// L1: Register File (per PE) — 1 cycle latency
// L2: Local SRAM (per cluster) — 32MB — 5 cycles
// L3: Shared SRAM — 128MB — 30 cycles
// L4: HBM3 — 96GB — 150 cycles, 3.2 TB/s
// ============================================================

`timescale 1ns/1ps

module memory_controller #(
    parameter DATA_WIDTH    = 256,    // 256-bit wide memory bus
    parameter ADDR_WIDTH    = 37,     // 128GB addressable (2^37 bytes)
    parameter SRAM_SIZE     = 131072, // 128MB L3 SRAM (in KB)
    parameter BURST_LEN     = 8       // 8 beats per burst
)(
    input  wire                    clk,
    input  wire                    rst_n,

    // ---- Compute Cluster Interface (4 clusters) ----
    // Cluster 0
    input  wire                    cl0_req,
    input  wire                    cl0_wr,          // 1=write, 0=read
    input  wire [ADDR_WIDTH-1:0]   cl0_addr,
    input  wire [DATA_WIDTH-1:0]   cl0_wdata,
    output reg  [DATA_WIDTH-1:0]   cl0_rdata,
    output reg                     cl0_ack,

    // Cluster 1
    input  wire                    cl1_req,
    input  wire                    cl1_wr,
    input  wire [ADDR_WIDTH-1:0]   cl1_addr,
    input  wire [DATA_WIDTH-1:0]   cl1_wdata,
    output reg  [DATA_WIDTH-1:0]   cl1_rdata,
    output reg                     cl1_ack,

    // Cluster 2
    input  wire                    cl2_req,
    input  wire                    cl2_wr,
    input  wire [ADDR_WIDTH-1:0]   cl2_addr,
    input  wire [DATA_WIDTH-1:0]   cl2_wdata,
    output reg  [DATA_WIDTH-1:0]   cl2_rdata,
    output reg                     cl2_ack,

    // Cluster 3
    input  wire                    cl3_req,
    input  wire                    cl3_wr,
    input  wire [ADDR_WIDTH-1:0]   cl3_addr,
    input  wire [DATA_WIDTH-1:0]   cl3_wdata,
    output reg  [DATA_WIDTH-1:0]   cl3_rdata,
    output reg                     cl3_ack,

    // ---- HBM3 Interface ----
    output reg                     hbm_req,
    output reg                     hbm_wr,
    output reg  [ADDR_WIDTH-1:0]   hbm_addr,
    output reg  [DATA_WIDTH-1:0]   hbm_wdata,
    input  wire [DATA_WIDTH-1:0]   hbm_rdata,
    input  wire                    hbm_ack,
    input  wire                    hbm_ready,

    // ---- Status ----
    output reg  [31:0]             l3_hit_count,
    output reg  [31:0]             l3_miss_count,
    output reg  [7:0]              bandwidth_util   // 0-100%
);

    // --------------------------------------------------------
    // Memory Map
    // 0x000_0000_0000 — 0x000_0FFF_FFFF : L3 SRAM (128MB)
    // 0x000_1000_0000 — 0x017_FFFF_FFFF : HBM3 (96GB)
    // --------------------------------------------------------
    localparam L3_BASE  = 37'h000_0000_0000;
    localparam L3_LIMIT = 37'h000_0FFF_FFFF;
    localparam HBM_BASE = 37'h000_1000_0000;

    // --------------------------------------------------------
    // L3 SRAM Model (128MB)
    // In real chip: SRAM compiler generates this
    // --------------------------------------------------------
    reg [DATA_WIDTH-1:0] l3_sram [0:(SRAM_SIZE*1024/32)-1];
    wire [ADDR_WIDTH-1:0] l3_index;
    assign l3_index = cl0_addr >> 5; // 32-byte aligned

    // --------------------------------------------------------
    // Arbiter — Round Robin among 4 clusters
    // --------------------------------------------------------
    reg [1:0] arb_grant;      // Current grant
    reg [1:0] arb_priority;   // Next priority

    wire [3:0] req_bus = {cl3_req, cl2_req, cl1_req, cl0_req};

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            arb_grant    <= 2'b00;
            arb_priority <= 2'b00;
        end else begin
            // Round-robin: check from arb_priority
            case (arb_priority)
                2'b00: begin
                    if      (cl0_req) arb_grant <= 2'b00;
                    else if (cl1_req) arb_grant <= 2'b01;
                    else if (cl2_req) arb_grant <= 2'b10;
                    else if (cl3_req) arb_grant <= 2'b11;
                end
                2'b01: begin
                    if      (cl1_req) arb_grant <= 2'b01;
                    else if (cl2_req) arb_grant <= 2'b10;
                    else if (cl3_req) arb_grant <= 2'b11;
                    else if (cl0_req) arb_grant <= 2'b00;
                end
                2'b10: begin
                    if      (cl2_req) arb_grant <= 2'b10;
                    else if (cl3_req) arb_grant <= 2'b11;
                    else if (cl0_req) arb_grant <= 2'b00;
                    else if (cl1_req) arb_grant <= 2'b01;
                end
                2'b11: begin
                    if      (cl3_req) arb_grant <= 2'b11;
                    else if (cl0_req) arb_grant <= 2'b00;
                    else if (cl1_req) arb_grant <= 2'b01;
                    else if (cl2_req) arb_grant <= 2'b10;
                end
            endcase

            if (|req_bus)
                arb_priority <= arb_grant + 1;
        end
    end

    // --------------------------------------------------------
    // Memory FSM
    // --------------------------------------------------------
    localparam ST_IDLE      = 3'd0;
    localparam ST_L3_READ   = 3'd1;
    localparam ST_L3_WRITE  = 3'd2;
    localparam ST_HBM_REQ   = 3'd3;
    localparam ST_HBM_WAIT  = 3'd4;
    localparam ST_RESPOND   = 3'd5;

    reg [2:0] state;
    reg [ADDR_WIDTH-1:0] current_addr;
    reg [DATA_WIDTH-1:0] current_data;
    reg                  current_wr;
    reg [1:0]            current_cluster;
    reg [DATA_WIDTH-1:0] response_data;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state           <= ST_IDLE;
            hbm_req         <= 1'b0;
            hbm_wr          <= 1'b0;
            l3_hit_count    <= 32'd0;
            l3_miss_count   <= 32'd0;
            bandwidth_util  <= 8'd0;
            cl0_ack <= 1'b0; cl1_ack <= 1'b0;
            cl2_ack <= 1'b0; cl3_ack <= 1'b0;

        end else begin
            // Default: deassert acks
            cl0_ack <= 1'b0; cl1_ack <= 1'b0;
            cl2_ack <= 1'b0; cl3_ack <= 1'b0;

            case (state)
                ST_IDLE: begin
                    hbm_req <= 1'b0;
                    if (|req_bus) begin
                        current_cluster <= arb_grant;
                        case (arb_grant)
                            2'b00: begin current_addr <= cl0_addr; current_wr <= cl0_wr; current_data <= cl0_wdata; end
                            2'b01: begin current_addr <= cl1_addr; current_wr <= cl1_wr; current_data <= cl1_wdata; end
                            2'b10: begin current_addr <= cl2_addr; current_wr <= cl2_wr; current_data <= cl2_wdata; end
                            2'b11: begin current_addr <= cl3_addr; current_wr <= cl3_wr; current_data <= cl3_wdata; end
                        endcase

                        // Check if L3 or HBM
                        if (current_addr <= L3_LIMIT)
                            state <= current_wr ? ST_L3_WRITE : ST_L3_READ;
                        else
                            state <= ST_HBM_REQ;
                    end
                end

                ST_L3_READ: begin
                    response_data <= l3_sram[current_addr[ADDR_WIDTH-1:5]];
                    l3_hit_count  <= l3_hit_count + 1;
                    state         <= ST_RESPOND;
                end

                ST_L3_WRITE: begin
                    l3_sram[current_addr[ADDR_WIDTH-1:5]] <= current_data;
                    l3_hit_count <= l3_hit_count + 1;
                    state        <= ST_RESPOND;
                end

                ST_HBM_REQ: begin
                    hbm_req   <= 1'b1;
                    hbm_addr  <= current_addr;
                    hbm_wr    <= current_wr;
                    hbm_wdata <= current_data;
                    l3_miss_count <= l3_miss_count + 1;
                    if (hbm_ready)
                        state <= ST_HBM_WAIT;
                end

                ST_HBM_WAIT: begin
                    hbm_req <= 1'b0;
                    if (hbm_ack) begin
                        response_data <= hbm_rdata;
                        state         <= ST_RESPOND;
                    end
                end

                ST_RESPOND: begin
                    case (current_cluster)
                        2'b00: begin cl0_rdata <= response_data; cl0_ack <= 1'b1; end
                        2'b01: begin cl1_rdata <= response_data; cl1_ack <= 1'b1; end
                        2'b10: begin cl2_rdata <= response_data; cl2_ack <= 1'b1; end
                        2'b11: begin cl3_rdata <= response_data; cl3_ack <= 1'b1; end
                    endcase
                    state <= ST_IDLE;
                end

                default: state <= ST_IDLE;
            endcase
        end
    end

    // --------------------------------------------------------
    // Bandwidth utilization monitor
    // --------------------------------------------------------
    reg [7:0] busy_cycles;
    reg [7:0] total_cycles;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            busy_cycles    <= 0;
            total_cycles   <= 0;
            bandwidth_util <= 0;
        end else begin
            total_cycles <= total_cycles + 1;
            if (state != ST_IDLE)
                busy_cycles <= busy_cycles + 1;

            if (total_cycles == 8'd99) begin
                bandwidth_util <= busy_cycles;
                busy_cycles    <= 0;
                total_cycles   <= 0;
            end
        end
    end

endmodule
