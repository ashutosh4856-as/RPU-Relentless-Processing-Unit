// ============================================================
// RPU — Relentless Processing Unit
// Rajput Tech (RT Ecosystem)
// File: rpu_top.v
// Description: RPU Top-Level Module — पूरी chip का integration
//
// यह file पूरे chip का "दरवाज़ा" है।
// सभी modules यहाँ connect होते हैं।
//
// Architecture:
// ├── 4× Compute Clusters
// │   └── Each: Systolic Array + Sparse Engine + Vector Unit
// ├── Memory Controller (L3 SRAM + HBM3)
// ├── Dataflow Network (On-chip Mesh NoC)
// ├── RPU-Link (chip-to-chip interconnect)
// └── PCIe Gen5 Interface (host connection)
// ============================================================

`timescale 1ns/1ps

module rpu_top #(
    parameter ARRAY_SIZE  = 512,
    parameter DATA_WIDTH  = 16,
    parameter ACC_WIDTH   = 32,
    parameter ADDR_WIDTH  = 37,
    parameter BUS_WIDTH   = 256,
    parameter NUM_CLUSTERS = 4
)(
    // ---- System ----
    input  wire         clk_main,      // 2GHz main clock
    input  wire         clk_hbm,       // 1.2GHz HBM clock
    input  wire         clk_pcie,      // PCIe ref clock
    input  wire         rst_n,         // Active low reset
    input  wire         pwr_good,      // Power good signal

    // ---- PCIe Gen5 x16 (Host Interface) ----
    input  wire [15:0]  pcie_rx,
    output wire [15:0]  pcie_tx,
    input  wire         pcie_rst_n,

    // ---- HBM3 Interface (96GB) ----
    inout  wire [1023:0] hbm_dq,       // 1024-bit HBM data bus
    output wire [31:0]   hbm_addr,
    output wire          hbm_cs_n,
    output wire          hbm_ras_n,
    output wire          hbm_cas_n,
    output wire          hbm_we_n,

    // ---- RPU-Link (chip-to-chip, 900 GB/s) ----
    input  wire [255:0]  rpulink_rx,
    output wire [255:0]  rpulink_tx,
    input  wire          rpulink_clk_in,
    output wire          rpulink_clk_out,
    input  wire          rpulink_valid_in,
    output wire          rpulink_valid_out,

    // ---- Status & Debug ----
    output wire [7:0]   led_status,
    output wire         error_flag,
    output wire [31:0]  perf_counter,  // Operations per second
    output wire [7:0]   temp_sensor,   // Die temperature (Celsius)
    output wire [7:0]   power_watts    // Current power draw
);

    // ============================================================
    // Internal Wires
    // ============================================================

    // Cluster outputs
    wire [ACC_WIDTH*ARRAY_SIZE-1:0] cl_result [0:NUM_CLUSTERS-1];
    wire [NUM_CLUSTERS-1:0]         cl_done;
    wire [NUM_CLUSTERS-1:0]         cl_result_valid;
    wire [15:0]                     cl_sparsity [0:NUM_CLUSTERS-1];

    // Memory controller
    wire [NUM_CLUSTERS-1:0]         mem_req;
    wire [NUM_CLUSTERS-1:0]         mem_wr;
    wire [ADDR_WIDTH-1:0]           mem_addr [0:NUM_CLUSTERS-1];
    wire [BUS_WIDTH-1:0]            mem_wdata [0:NUM_CLUSTERS-1];
    wire [BUS_WIDTH-1:0]            mem_rdata [0:NUM_CLUSTERS-1];
    wire [NUM_CLUSTERS-1:0]         mem_ack;

    // HBM internal
    wire                            hbm_req_int;
    wire                            hbm_wr_int;
    wire [ADDR_WIDTH-1:0]           hbm_addr_int;
    wire [BUS_WIDTH-1:0]            hbm_wdata_int;
    wire [BUS_WIDTH-1:0]            hbm_rdata_int;
    wire                            hbm_ack_int;
    wire                            hbm_ready_int;

    // Dataflow control
    wire [NUM_CLUSTERS-1:0]         cluster_enable;
    wire [31:0]                     noc_status;
    wire                            training_mode;
    wire                            inference_mode;

    // PCIe decoded commands
    wire [DATA_WIDTH*ARRAY_SIZE-1:0] host_weight_data;
    wire [DATA_WIDTH*ARRAY_SIZE-1:0] host_act_data;
    wire                             host_data_valid;
    wire                             host_start_compute;
    wire                             host_clear_acc;
    wire [ADDR_WIDTH-1:0]            host_dma_src;
    wire [ADDR_WIDTH-1:0]            host_dma_dst;
    wire [31:0]                      host_dma_len;

    // ============================================================
    // Compute Clusters (4x)
    // ============================================================
    genvar cl;
    generate
        for (cl = 0; cl < NUM_CLUSTERS; cl = cl + 1) begin : compute_cluster

            sparse_matrix_engine #(
                .ARRAY_SIZE  (ARRAY_SIZE),
                .DATA_WIDTH  (DATA_WIDTH),
                .ACC_WIDTH   (ACC_WIDTH)
            ) u_sme (
                .clk              (clk_main),
                .rst_n            (rst_n),
                .enable           (cluster_enable[cl]),

                // Data from memory (via NoC)
                .weight_dense     (host_weight_data),
                .act_dense        (host_act_data),
                .data_valid       (host_data_valid & cluster_enable[cl]),

                // Results
                .result_out       (cl_result[cl]),
                .result_valid     (cl_result_valid[cl]),
                .done             (cl_done[cl]),

                // Sparsity stats
                .weight_sparsity  (cl_sparsity[cl]),
                .act_sparsity     (),
                .effective_speedup()
            );
        end
    endgenerate

    // ============================================================
    // Memory Controller
    // ============================================================
    memory_controller #(
        .DATA_WIDTH (BUS_WIDTH),
        .ADDR_WIDTH (ADDR_WIDTH)
    ) u_mem_ctrl (
        .clk           (clk_main),
        .rst_n         (rst_n),

        // Cluster 0
        .cl0_req       (mem_req[0]),
        .cl0_wr        (mem_wr[0]),
        .cl0_addr      (mem_addr[0]),
        .cl0_wdata     (mem_wdata[0]),
        .cl0_rdata     (mem_rdata[0]),
        .cl0_ack       (mem_ack[0]),

        // Cluster 1
        .cl1_req       (mem_req[1]),
        .cl1_wr        (mem_wr[1]),
        .cl1_addr      (mem_addr[1]),
        .cl1_wdata     (mem_wdata[1]),
        .cl1_rdata     (mem_rdata[1]),
        .cl1_ack       (mem_ack[1]),

        // Cluster 2
        .cl2_req       (mem_req[2]),
        .cl2_wr        (mem_wr[2]),
        .cl2_addr      (mem_addr[2]),
        .cl2_wdata     (mem_wdata[2]),
        .cl2_rdata     (mem_rdata[2]),
        .cl2_ack       (mem_ack[2]),

        // Cluster 3
        .cl3_req       (mem_req[3]),
        .cl3_wr        (mem_wr[3]),
        .cl3_addr      (mem_addr[3]),
        .cl3_wdata     (mem_wdata[3]),
        .cl3_rdata     (mem_rdata[3]),
        .cl3_ack       (mem_ack[3]),

        // HBM
        .hbm_req       (hbm_req_int),
        .hbm_wr        (hbm_wr_int),
        .hbm_addr      (hbm_addr_int),
        .hbm_wdata     (hbm_wdata_int),
        .hbm_rdata     (hbm_rdata_int),
        .hbm_ack       (hbm_ack_int),
        .hbm_ready     (hbm_ready_int),

        .l3_hit_count  (),
        .l3_miss_count (),
        .bandwidth_util()
    );

    // ============================================================
    // Dataflow Controller (Training vs Inference mode)
    // ============================================================
    rpu_dataflow_ctrl u_dataflow (
        .clk             (clk_main),
        .rst_n           (rst_n),
        .training_mode   (training_mode),
        .inference_mode  (inference_mode),
        .cl_done         (cl_done),
        .cl_result_valid (cl_result_valid),
        .cluster_enable  (cluster_enable),
        .noc_status      (noc_status)
    );

    // ============================================================
    // PCIe Interface (Host Communication)
    // ============================================================
    rpu_pcie_interface u_pcie (
        .clk_pcie         (clk_pcie),
        .clk_main         (clk_main),
        .rst_n            (rst_n & pcie_rst_n),
        .pcie_rx          (pcie_rx),
        .pcie_tx          (pcie_tx),
        .weight_data_out  (host_weight_data),
        .act_data_out     (host_act_data),
        .data_valid_out   (host_data_valid),
        .start_compute    (host_start_compute),
        .clear_acc        (host_clear_acc),
        .training_mode    (training_mode),
        .inference_mode   (inference_mode),
        .result_in        (cl_result[0]),       // Primary result
        .result_valid_in  (cl_result_valid[0])
    );

    // ============================================================
    // RPU-Link Interface (Chip-to-Chip)
    // ============================================================
    rpu_link_interface u_rpulink (
        .clk_main        (clk_main),
        .rst_n           (rst_n),
        .rx_data         (rpulink_rx),
        .tx_data         (rpulink_tx),
        .clk_in          (rpulink_clk_in),
        .clk_out         (rpulink_clk_out),
        .valid_in        (rpulink_valid_in),
        .valid_out       (rpulink_valid_out),
        .result_to_send  (cl_result[0]),
        .result_valid    (cl_result_valid[0])
    );

    // ============================================================
    // Performance Counter
    // ============================================================
    reg [31:0] ops_counter;
    reg [31:0] perf_reg;

    always @(posedge clk_main or negedge rst_n) begin
        if (!rst_n) begin
            ops_counter <= 32'd0;
            perf_reg    <= 32'd0;
        end else begin
            if (|cl_result_valid) begin
                // Each valid output = ARRAY_SIZE² × NUM_CLUSTERS operations
                ops_counter <= ops_counter + (ARRAY_SIZE * ARRAY_SIZE * NUM_CLUSTERS);
            end

            // Update perf counter every 1M cycles
            if (ops_counter >= 32'd1_000_000) begin
                perf_reg    <= ops_counter;
                ops_counter <= 32'd0;
            end
        end
    end

    assign perf_counter = perf_reg;

    // ============================================================
    // Status LEDs
    // ============================================================
    assign led_status = {
        pwr_good,           // Bit 7: Power OK
        hbm_ready_int,      // Bit 6: HBM Ready
        |cl_done,           // Bit 5: Compute Done
        training_mode,      // Bit 4: Training Mode
        inference_mode,     // Bit 3: Inference Mode
        |cl_result_valid,   // Bit 2: Results Ready
        |mem_req,           // Bit 1: Memory Active
        error_flag          // Bit 0: Error
    };

    // ============================================================
    // Error Detection
    // ============================================================
    assign error_flag = (~pwr_good) | (~hbm_ready_int & hbm_req_int);

    // ============================================================
    // Power & Temp (placeholder — real values from sensors)
    // ============================================================
    assign temp_sensor = 8'd65;    // 65°C nominal
    assign power_watts = 8'd180;   // 180W typical

endmodule


// ============================================================
// Dataflow Controller — Training/Inference Mode Switch
// यह RPU का दूसरा बड़ा innovation है
// ============================================================
module rpu_dataflow_ctrl (
    input  wire         clk,
    input  wire         rst_n,
    input  wire         training_mode,
    input  wire         inference_mode,
    input  wire [3:0]   cl_done,
    input  wire [3:0]   cl_result_valid,
    output reg  [3:0]   cluster_enable,
    output reg  [31:0]  noc_status
);
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            cluster_enable <= 4'b1111;  // All clusters enabled by default
            noc_status     <= 32'd0;
        end else begin
            if (training_mode) begin
                // Training: All 4 clusters work together (pipeline)
                cluster_enable <= 4'b1111;
                noc_status[1:0] <= 2'b01; // Training mode indicator
            end else if (inference_mode) begin
                // Inference: Clusters work independently (parallel requests)
                cluster_enable <= 4'b1111;
                noc_status[1:0] <= 2'b10; // Inference mode indicator
            end else begin
                cluster_enable <= 4'b0000;
            end

            noc_status[7:4] <= cl_done;
            noc_status[11:8] <= cl_result_valid;
        end
    end
endmodule


// ============================================================
// PCIe Interface Stub (Full implementation separate file)
// ============================================================
module rpu_pcie_interface (
    input  wire         clk_pcie,
    input  wire         clk_main,
    input  wire         rst_n,
    input  wire [15:0]  pcie_rx,
    output wire [15:0]  pcie_tx,
    output wire [8191:0] weight_data_out,
    output wire [8191:0] act_data_out,
    output wire         data_valid_out,
    output wire         start_compute,
    output wire         clear_acc,
    output wire         training_mode,
    output wire         inference_mode,
    input  wire [16383:0] result_in,
    input  wire         result_valid_in
);
    // Stub — full PCIe Gen5 implementation in pcie_interface.v
    assign pcie_tx        = 16'h0;
    assign weight_data_out = {8192{1'b0}};
    assign act_data_out    = {8192{1'b0}};
    assign data_valid_out  = 1'b0;
    assign start_compute   = 1'b0;
    assign clear_acc       = 1'b0;
    assign training_mode   = 1'b1;  // Default: training mode
    assign inference_mode  = 1'b0;
endmodule


// ============================================================
// RPU-Link Interface Stub
// ============================================================
module rpu_link_interface (
    input  wire         clk_main,
    input  wire         rst_n,
    input  wire [255:0] rx_data,
    output wire [255:0] tx_data,
    input  wire         clk_in,
    output wire         clk_out,
    input  wire         valid_in,
    output wire         valid_out,
    input  wire [16383:0] result_to_send,
    input  wire         result_valid
);
    // Stub — full RPU-Link in rpulink.v
    assign tx_data   = 256'h0;
    assign clk_out   = clk_main;
    assign valid_out = result_valid;
endmodule
